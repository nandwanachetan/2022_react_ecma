import React from 'react';
// import RouteConsent from '../common/RouteConsent';

const HomeComponent = () => {
    return (
        <div className='text-center'>
            <h1 className="text-primary">Home Component</h1>
            <h4 className="text-warning">This is a Simple, React Routing Application</h4>
        
            {/* <RouteConsent /> */}
        </div>
    );
};

export default HomeComponent;