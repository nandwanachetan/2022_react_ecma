// npm i history@4
import { createBrowserHistory } from 'history';

export default createBrowserHistory();